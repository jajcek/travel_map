package com.ick.paint.tools;

import com.ick.paint.gui.ImagePanel;

import java.awt.*;
import java.util.Random;

/**
 * Created by jajcek on 21.12.13.
 */
public class Spray extends BasicTool {
	Thread drawingThread;
	boolean isDrawing;

    int xDrawingPosition;
    int yDrawingPosition;

	public Spray(ImagePanel imagePanel) {
		super(imagePanel);
        toolName = "Spray";
        width = 20;
	}

	public void startDrawing(final int timeBetweenPixels) {
		stopDrawing();
        isDrawing = true;
		drawingThread = new Thread(new Runnable() {
			@Override
			public void run() {
				while (true) {
					try {
						Thread.sleep(timeBetweenPixels);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}

					Point pointInCircle = getRandomCircleValue(getWidth());
					int xSprayPos = (int) (pointInCircle.getX() + xDrawingPosition);
					int ySprayPos = (int) (pointInCircle.getY() + yDrawingPosition);

                    xSprayPos = clamp(xSprayPos, 0, imagePanel.getImage().getWidth());
					ySprayPos = clamp(ySprayPos, 0, imagePanel.getImage().getHeight());

                    try {
                        imagePanel.getImage().setRGB(xSprayPos, ySprayPos, getColor().getRGB());
                    } catch(Exception ex) {}

					imagePanel.repaint();
				}
			}
		});

		drawingThread.start();
	}

	private Point getRandomCircleValue(int radius) {
		double t = 2 * Math.PI * new Random().nextDouble();
		double u = new Random().nextDouble() + new Random().nextDouble();
		double r = u > 1 ? 2 - u : u;

		int x = (int) (Math.cos(t) * r * radius);
		int y = (int) (Math.sin(t) * r * radius);

		return new Point(x, y);
	}

	private int clamp(int value, int from, int to) {
		if (value < from)
			return from;
		if (value > to)
			return to;

		return value;
	}

    @Override
	public void stopDrawing() {
		isDrawing = false;
        if (drawingThread != null)
            drawingThread.stop();
	}

	@Override
	public void useTool(int xStart, int yStart, int xEnd, int yEnd) {
        xDrawingPosition = xStart;
        yDrawingPosition = yStart;

        if (!isDrawing) {
            int drawingPixelLatency = 1;
            startDrawing(drawingPixelLatency);
        }
	}

}
