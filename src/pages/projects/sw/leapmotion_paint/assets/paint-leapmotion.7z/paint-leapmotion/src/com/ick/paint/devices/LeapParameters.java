package com.ick.paint.devices;

public class LeapParameters {

	public final static float DRAWING_DEPTH = 0.4f;
	public final static float MENU_DEPTH = 0.8f;
	
}
