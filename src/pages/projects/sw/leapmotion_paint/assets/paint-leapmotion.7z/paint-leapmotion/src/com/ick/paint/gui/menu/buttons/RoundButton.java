package com.ick.paint.gui.menu.buttons;

import java.awt.AlphaComposite;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;

import com.ick.paint.gui.MainWindow;

public class RoundButton extends MenuButton {

	public RoundButton() {
		super();
	}

	public RoundButton(Point rotationPointCenter) {
		super();
		this.rotationPointCenter = rotationPointCenter;
	}

	public RoundButton(String label) {
		super();
		setText(label);
	}

	protected void paintComponent(Graphics graphic) {

		Graphics2D g = (Graphics2D) graphic;
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER,
				opacity / 255f));

		if (getModel().isSelected()) {
			g.setColor(backgroundColors.getSelected());
		} else if (getModel().isPressed()) {
			g.setColor(backgroundColors.getClicked());
		} else {
			g.setColor(backgroundColors.getStandard());
		}

		g.fillOval(0, 0, getSize().width - 1, getSize().height - 1);

		setForeground(foregroundColor); // tu przezroczystość nic nie daje ;(
		super.paintComponent(g);
	}

	protected void paintBorder(Graphics g) {
		Graphics2D g2d = (Graphics2D) g;
		g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER,
				opacity / 255f));

		if (getModel().isSelected()) {
			g2d.setColor(borderColors.getSelected());
		} else if (getModel().isPressed()) {
			g2d.setColor(borderColors.getClicked());
		} else {
			g2d.setColor(borderColors.getStandard());
		}
		g2d.drawOval(0, 0, getSize().width - 1, getSize().height - 1);
	}

	@Override
	public boolean contains(int x, int y) {
		// to tak na pałe ale już mam dosyć
		if (!MainWindow.USE_LEAPMOTION) {
			return super.contains(x, y);
		}

		if (shape == null || !shape.getBounds().equals(getBounds())) {
			shape = new Ellipse2D.Float(getX(), getY(), getWidth(), getHeight());
		}
		//System.out.println(">          contains x: " + x + ", y: " + y + "; shape: " + shape.getBounds());

		return shape.contains(x, y);
	}
}
