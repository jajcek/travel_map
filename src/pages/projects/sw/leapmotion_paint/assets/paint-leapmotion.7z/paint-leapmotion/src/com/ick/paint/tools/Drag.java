package com.ick.paint.tools;

import com.ick.paint.gui.ImagePanel;

public class Drag extends BasicTool {

	public Drag(ImagePanel imagePanel) {
		super(imagePanel);
        toolName = "Drag";
	}
	
	@Override
	public void useTool(int xStart, int yStart, int xEnd, int yEnd) {
		imagePanel.dragImage(xEnd - xStart, yEnd - yStart);
	}

}
