package com.ick.paint.gui.menu;

import java.awt.Container;
import java.awt.event.ActionListener;

import com.ick.paint.gui.menu.buttons.MenuButton;

public class PaintMenu {
	protected int containerWidth;
	protected int containerHeight;
	protected int buttonSizeX;
	protected int buttonSizeY;
	protected boolean visible;
	protected int selectedOption;
		
	Container container;
	MenuButton[] buttons;

	public PaintMenu(Container container) {

		containerWidth = container.getWidth();
		containerHeight = container.getHeight();

		this.container = container;
		visible = true;

	}

	public void setVisible(boolean visible) {
		if (this.visible != visible) {
			this.visible = visible;
			for (int i = 0; i < buttons.length / 2; i++) {
				buttons[i].setVisible(visible);
				buttons[buttons.length - 1 - i].setVisible(visible);
			}
		}
	}

	public MenuButton rollover(int x, int y) {
		if (!visible)
            return null;

        MenuButton selectedButton = null;
        for (MenuButton butt : buttons) {
            if (!butt.isVisible())
                continue;

            if (butt.contains(x, y)) {
                if (!butt.isSelected()) {
                    butt.setSelected(true);
                    butt.doClick();
                    selectedButton = butt;
                }
            } else {
                butt.setSelected(false);
            }
        }

        return selectedButton;
	}

	public boolean isVisible() {
		return visible;
	}
	
	public void addActionListener(ActionListener actionListener) {
		for (int i = 0; i < buttons.length; i++) {
			buttons[i].addActionListener(actionListener);
		}
	}
}
