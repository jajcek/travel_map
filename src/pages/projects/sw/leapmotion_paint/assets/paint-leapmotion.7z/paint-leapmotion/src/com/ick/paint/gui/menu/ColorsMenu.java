package com.ick.paint.gui.menu;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import aurelienribon.tweenengine.BaseTween;
import aurelienribon.tweenengine.Timeline;
import aurelienribon.tweenengine.Tween;
import aurelienribon.tweenengine.TweenCallback;
import aurelienribon.tweenengine.equations.Quart;

import com.ick.paint.gui.menu.buttons.Colors;
import com.ick.paint.gui.menu.buttons.MenuButton;
import com.ick.paint.gui.menu.buttons.RectButton;
import com.ick.paint.gui.tween.TweenAnimationsTool;
import com.ick.paint.gui.tween.tweenaccessor.MenuButtonAccessor;

public class ColorsMenu extends PaintMenu {

	public static final int NUMBEROFCOLORS = 66; // ma być parzyste

	private Timeline showButtons;
	private Timeline hideButtons;

	protected boolean isColorAnimationFired;

	public ColorsMenu(Container container) {
		super(container);
		visible = false;

		createButtons();
		addButtonsToView();
	}

	public void createButtons() {
		buttons = new MenuButton[NUMBEROFCOLORS];
		buttonSizeX = 20;
		buttonSizeY = 100;

		Color[] c = generateColors(buttons.length);

		ColorButtonMouseListener colorButtonListener = new ColorButtonMouseListener();

		for (int i = 0; i < buttons.length; i++) {
			final RectButton button = new RectButton();
			button.setPaintBorder(true);
			button.setOpacity(0);
			button.setBackgroundColors(new Colors(c[i]));
			button.setActionObject(c[i]);

			button.addMouseListener(colorButtonListener);

			buttons[i] = button;
		}
	}

	private void addButtonsToView() {
		int xPos = container.getWidth() / 2 - (NUMBEROFCOLORS * buttonSizeX / 2);

		for (int i = 0; i < buttons.length; i++) {
			buttons[i].setBounds(xPos + i * buttonSizeX, containerHeight,
					buttonSizeX, buttonSizeY);
			buttons[i].setTargetPosition(new Point(xPos + i * buttonSizeX,
                    containerHeight - buttonSizeY));
			container.add(buttons[i]);
		}

		// reczne odpalenie show a na koniec hide, trochę na pałe ale nie chce
		// mi sie przerabiać
		visible = true;
		getShowButtonsTimeline().delay(2500)
				.setCallbackTriggers(TweenCallback.END)
				.setCallback(new TweenCallback() {
					@Override
					public void onEvent(int type, BaseTween<?> source) {
						setVisible(false);
					}
				}).start(TweenAnimationsTool.getInstance().getTweenManager());
		TweenAnimationsTool.getInstance().start();
	}

	private Timeline getHideButtonsTimeline() {
		hideButtons = Timeline.createParallel();
		// Pozdrowienia dla Pawła :D - moja jest jeszcze lepsza :D
		for (int i = buttons.length / 2 - 1, j = i + 1; i >= 0; i--, j++) {
			// for (int i = 0; i < buttons.length; i++) {
			// System.out.println("magic loop i=" + i + " , j=" + j);
			// pierwszy (dla i)
			hideButtons.push(
					Tween.to(buttons[i], MenuButtonAccessor.POSITION, 300)
							.ease(Quart.IN)
							.target((float) buttons[i].getLocation().getX(),
									(float) containerHeight)
							.delay((j - 1 - i) * 5)).push(
					Tween.to(buttons[i], MenuButtonAccessor.OPACITY, 200)
							.ease(Quart.IN).target(0).delay((j - 1 - i) * 5));
			// drugi (dla j)
			hideButtons.push(
					Tween.to(buttons[j], MenuButtonAccessor.POSITION, 300)
							.ease(Quart.IN)
							.target((float) buttons[j].getLocation().getX(),
									(float) containerHeight)
							.delay((j - 1 - i) * 5)).push(
					Tween.to(buttons[j], MenuButtonAccessor.OPACITY, 200)
							.ease(Quart.IN).target(0).delay((j - 1 - i) * 5));

		}
		hideButtons
				.setCallbackTriggers(TweenCallback.BEGIN | TweenCallback.END)
				.setCallback(new TweenCallback() {
                    @Override
                    public void onEvent(int type, BaseTween<?> source) {
                        if (type == BEGIN) {
                            isColorAnimationFired = true;
                        } else if (type == END) {
                            visible = false;
                            isColorAnimationFired = false;
                        }
                    }
                });

		return hideButtons;
	}

	private Timeline getShowButtonsTimeline() {
		showButtons = Timeline.createParallel();
		// for (int i = 0; i < buttons.length; i++) {
		for (int i = buttons.length / 2 - 1, j = i + 1; i >= 0; i--, j++) {
			showButtons.push(
					Tween.to(buttons[i], MenuButtonAccessor.POSITION, 300)
							.ease(Quart.IN)
							.target((float) buttons[i].getLocation().getX(),
									(float) buttons[i].getLocation().getY()
											- buttonSizeY)
							.delay((j - 1 - i) * 5)).push(
					Tween.to(buttons[i], MenuButtonAccessor.OPACITY, 300)
							.ease(Quart.IN).target(255).delay((j - 1 - i) * 5));
			showButtons.push(
					Tween.to(buttons[j], MenuButtonAccessor.POSITION, 300)
							.ease(Quart.IN)
							.target((float) buttons[j].getLocation().getX(),
									(float) buttons[j].getLocation().getY()
											- buttonSizeY)
							.delay((j - 1 - i) * 5)).push(
					Tween.to(buttons[j], MenuButtonAccessor.OPACITY, 200)
							.ease(Quart.IN).target(255).delay((j - 1 - i) * 5));
		}
		showButtons
				.setCallbackTriggers(TweenCallback.BEGIN | TweenCallback.END)
				.setCallback(new TweenCallback() {

					@Override
					public void onEvent(int type, BaseTween<?> source) {

						if (type == BEGIN) {
							isColorAnimationFired = true;
						} else if (type == END) {
							visible = true;
							isColorAnimationFired = false;
						}
					}
				});

		return showButtons;
	}

	@Override
	public void setVisible(boolean visible) {
		if (this.visible == visible)
			return;

		if (!isColorAnimationFired) {
			if (visible) {
				getShowButtonsTimeline().start(
                        TweenAnimationsTool.getInstance().getTweenManager());
			} else {
				getHideButtonsTimeline().start(
                        TweenAnimationsTool.getInstance().getTweenManager());
			}
			TweenAnimationsTool.getInstance().start();
		}
	}

	private Color[] generateColors(int n) {
		Color[] cols = new Color[n];
		for (int i = 0; i < n - 2; i++) {
			cols[i] = Color.getHSBColor((float) i / (float) n, 0.85f, 1.0f);
		}
		cols[n - 2] = Color.white;
		cols[n - 1] = Color.black;
		return cols;
	}

	private void moveButons(MenuButton button) {
		boolean moveToLeft = true;
		for (int i = 0; i < buttons.length; i++) {
			RectButton b = (RectButton) buttons[i];

			if (button == null) {
				b.moveToPosition(0);
                continue;
			}

			if (b == button) {
				b.moveToPosition(0);
				moveToLeft = false;
			} else if (moveToLeft) {
				b.moveToPosition(-1);
			} else {
				b.moveToPosition(1);
			}
		}
	}

	@Override
	public MenuButton rollover(int x, int y) {
        if (!visible)
            return null;

        MenuButton butt = super.rollover(x, y);
        if (butt != null)
            moveButons(butt);

        return butt;
	}

	class ColorButtonMouseListener implements MouseListener {

		@Override
		public void mouseClicked(MouseEvent e) {
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			RectButton button = (RectButton) e.getSource();
			button.setSelected(true);
			moveButons(button);
		}

		@Override
		public void mouseExited(MouseEvent e) {
			RectButton button = (RectButton) e.getSource();
			button.setSelected(false);
			moveButons(button);
		}

		@Override
		public void mousePressed(MouseEvent e) {
		}

		@Override
		public void mouseReleased(MouseEvent e) {
		}

	}
}
