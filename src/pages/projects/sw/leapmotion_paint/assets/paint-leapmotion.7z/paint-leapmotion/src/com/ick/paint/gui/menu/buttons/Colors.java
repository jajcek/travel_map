package com.ick.paint.gui.menu.buttons;

import java.awt.Color;

public class Colors {

	private Color standard;
	private Color selected;
	private Color clicked;
	
	public Colors(Color standard) {
		this.standard = standard;
		this.selected = standard;
		this.clicked = standard;
	}
	
	public Colors(Color standard, Color selected, Color clicked) {
		this.standard = standard;
		this.selected = selected;
		this.clicked = clicked;
	}

	public Color getStandard() {
		return standard;
	}

	public void setStandard(Color standard) {
		this.standard = standard;
	}

	public Color getSelected() {
		return selected;
	}

	public void setSelected(Color selected) {
		this.selected = selected;
	}

	public Color getClicked() {
		return clicked;
	}

	public void setClicked(Color clicked) {
		this.clicked = clicked;
	}	
}