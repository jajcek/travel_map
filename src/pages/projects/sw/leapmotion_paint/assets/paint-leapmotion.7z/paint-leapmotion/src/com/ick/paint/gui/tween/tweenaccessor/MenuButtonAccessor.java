package com.ick.paint.gui.tween.tweenaccessor;

import aurelienribon.tweenengine.TweenAccessor;

import com.ick.paint.gui.menu.buttons.MenuButton;

public class MenuButtonAccessor implements TweenAccessor<MenuButton> {
        public static final int POSITION = 0;
        public static final int ROTATE = 1;
        public static final int OPACITY = 2;
        
        @Override
        public int getValues(MenuButton target, int tweenType, float[] returnValues) {
                switch (tweenType) {
                        case POSITION:
                                returnValues[0] = target.getX();
                                returnValues[1] = target.getY();
                                return 2;
                        case ROTATE:
                        	returnValues[0] = target.getRotation();
                        	return 1;
                        case OPACITY:
                        	returnValues[0] = target.getOpacity();
                        	return 1;
                }
                return 0;
        }

        @Override
        public void setValues(MenuButton target, int tweenType, float[] newValues) {
                switch (tweenType) {
                	case POSITION:
                		target.setLocation((int) newValues[0], (int) newValues[1]);
                		break;
                    case ROTATE:
                    	target.rotate(newValues[0]);
                    	break;
                    case OPACITY:
                    	target.setOpacity((int) newValues[0]);
                    	break;
                }
        }
        
}