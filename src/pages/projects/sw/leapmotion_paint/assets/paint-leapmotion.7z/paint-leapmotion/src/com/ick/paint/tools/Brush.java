package com.ick.paint.tools;

import java.awt.BasicStroke;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

import com.ick.paint.gui.ImagePanel;

public class Brush extends BasicTool {

    public Brush(ImagePanel imagePanel) {
        super(imagePanel);
        toolName = "Brush";
        width = 20;
    }

	@Override
	public void useTool(int xStart, int yStart, int xEnd, int yEnd) {
		Graphics2D image = (Graphics2D) imagePanel.getImage().getGraphics();
		
		image.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		
		image.setColor(getColor());
		image.setStroke(new BasicStroke(getWidth(), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
		
		image.drawLine(xStart, yStart, xEnd, yEnd);
	}

}
