package com.ick.paint.tools;


import com.ick.paint.gui.ImagePanel;

public enum PaintTool {
	PEN,
    SPRAY,
    ERASER,
    BRUSH,
    DRAG;
    
    public static BasicTool getBasicTool(PaintTool t, ImagePanel imagePanel) {
        switch(t){
            case PEN:
                return new Pen(imagePanel);
            case SPRAY:
                return new Spray(imagePanel);
            case ERASER:
                return new Eraser(imagePanel);
            case BRUSH:
                return new Brush(imagePanel);
            case DRAG:
                return new Drag(imagePanel);
            default:
                return null;
        }
    }
}
