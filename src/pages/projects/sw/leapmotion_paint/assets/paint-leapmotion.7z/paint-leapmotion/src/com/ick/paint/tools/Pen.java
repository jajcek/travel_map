package com.ick.paint.tools;

import com.ick.paint.gui.ImagePanel;

import java.awt.*;

/**
 * Created by jajcek on 21.12.13.
 */
public class Pen extends BasicTool {
	public Pen(ImagePanel imagePanel) {
		super(imagePanel);
        toolName = "Pen";
        color = Color.BLACK;
        width = 1;
	}

	@Override
	public void useTool(int xStart, int yStart, int xEnd, int yEnd) {
		Graphics2D image = (Graphics2D) imagePanel.getImage().getGraphics();
		
		image.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);

		image.setColor(getColor());
		image.setStroke(new BasicStroke(1)); //damy na pen zawsze jeden, pędzel będzie miał możliwość zmiany
		image.drawLine(xStart, yStart, xEnd, yEnd);
	}
}
