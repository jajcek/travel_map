package com.ick.paint.gui;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

public class ImagePanel extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private BufferedImage image;

	private int offsetX;
	private int offsetY;

	public ImagePanel() {
		setLayout(null);
		offsetX = 0;
		offsetY = 0;
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		if (image != null)
			g.drawImage(image, -offsetX, -offsetY, null);
	}

	public int getImageX(int windowX) {
		return windowX + offsetX;
	}

	public int getImageY(int windowY) {
		return windowY + offsetY;
	}

	public BufferedImage getImage() {
		if (image == null) {
			image = new BufferedImage(getWidth(), getHeight(),
					BufferedImage.TYPE_INT_ARGB);
			image.getGraphics().setColor(Color.WHITE);
			image.getGraphics().fillRect(0, 0, getWidth(), getHeight());
			repaint();
		}
		return image;
	}

	public void dragImage(int x, int y) {
		offsetX -= x;
		offsetY -= y;
		
		boolean sizeChanged = false;
		int newWidth = image.getWidth();
		int newHeight = image.getHeight();

		if (offsetX < 0) {
			newWidth -= offsetX;
			sizeChanged = true;
		}else if (image.getWidth() - offsetX < this.getWidth()){
			newWidth = this.getWidth() + offsetX;
			sizeChanged = true;
		}

		if (offsetY < 0) {
			newHeight -= offsetY;
			sizeChanged = true;
		}else if (image.getHeight() - offsetY < this.getHeight()){
			newHeight = this.getHeight() + offsetY;
			sizeChanged = true;
		}
		
		if(sizeChanged){
			BufferedImage temp = new BufferedImage(newWidth, newHeight,	BufferedImage.TYPE_INT_ARGB);
			
			Graphics g = temp.createGraphics();
			g.setColor(Color.WHITE);
			g.fillRect(0, 0, temp.getWidth(), temp.getHeight());
			
			g.drawImage(image, Math.max(-offsetX, 0), Math.max(-offsetY, 0), null);
	
			offsetX = Math.max(offsetX, 0);
			offsetY = Math.max(offsetY, 0);
			
			image = temp;
		}
	}
}
