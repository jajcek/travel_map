package com.ick.paint.devices;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;

import javax.swing.JComponent;

public class LeapPointer extends JComponent {

	private static boolean SHOW_CORDS = false;

	private int minSize = 0;
	private int maxSize = 50;
	private float depth;
	private boolean isPressed = false;
	private Point center;
	private Color fillColor = Color.GREEN;

	public LeapPointer() {
		super();
		System.out.println(getPreferredSize());
		setBounds(0, 0, 10, 10);
		setVisible(true);
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		if (isPressed) {
			g.setColor(getFillColor());
			g.fillOval(0, 0, getPointerSize() - 1, getPointerSize() - 1);
		}
		g.setColor(Color.RED);
		g.drawOval(0, 0, getPointerSize() - 1, getPointerSize() - 1);

		if (SHOW_CORDS) {
			g.setColor(Color.BLACK);
			g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 10));
			try {
				g.drawString("x:" + center.getX(), 0, getWidth() / 3);
				g.drawString("y:" + center.getY(), 0, getWidth() * 2 / 3);
			} catch (NullPointerException e) {

			}
		}
	}

	private int getPointerSize() {
		return (int) (maxSize * depth + minSize);
	}

	public Point getCenter() {
		return center;
	}

	public void setPosition(int x, int y, float z) {
		if (!isVisible())
			setVisible(true);

		depth = z < 0 ? 0 : z;
		center = new Point(x, y);
		setBounds(x - getPointerSize() / 2, y - getPointerSize() / 2,
				getPointerSize(), getPointerSize());

		if (depth < LeapParameters.DRAWING_DEPTH)
			isPressed = true;
		else
			isPressed = false;

		repaint();
	}

	public float getDepth() {
		return depth;
	}

	public void setDepth(float depth) {
		this.depth = depth;
	}

	public boolean isPressed() {
		return isPressed;
	}

	public void setPressed(boolean isPressed) {
		this.isPressed = isPressed;
	}

	public int getXCenterPosition() {
		return (int) center.getX();
	}

	public int getYCenterPosition() {
		return (int) center.getY();
	}

	public int getMinSize() {
		return minSize;
	}

	public void setMinSize(int minSize) {
		this.minSize = minSize;
	}

	public int getMaxSize() {
		return maxSize;
	}

	public void setMaxSize(int maxSize) {
		this.maxSize = maxSize;
	}

	public Color getFillColor() {
		return fillColor;
	}

	public void setFillColor(Color fillColor) {
		this.fillColor = fillColor;
	}
}
