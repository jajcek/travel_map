package com.ick.paint.gui.menu.buttons;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;

import javax.swing.JButton;

public abstract class MenuButton extends JButton {

	protected Shape shape;
	protected Point rotationPointCenter;
	protected Point2D currentLocationToRotate;
	protected float rotation = 0; // aktualny obrót
	protected int opacity = 255;

	protected Point targetPosition; //zapamiętuje pozycje po obrocie - wiem że średnio

	protected Color foregroundColor = new Color(53, 56, 51);
	protected Colors backgroundColors = new Colors(new Color(222, 227, 233), new Color(11, 119, 148), new Color(11, 119, 148));
	protected Colors borderColors = new Colors(new Color(220, 220, 220));
	protected boolean paintBorder = true;
	
	protected Object actionObject;
	
	public MenuButton() {
		super();

		Dimension size = getPreferredSize();
		size.width = size.height = Math.max(size.width, size.height);
		setPreferredSize(size);
		setContentAreaFilled(false);
		setFocusPainted(false);

		setBackground(new Color(178, 0, 250));
		setMultiClickThreshhold(1000);

		// do rotacji
		rotationPointCenter = new Point(getX(), getY());
	}

	public void rotate(float angleRadians) {
		if (currentLocationToRotate == null)
			currentLocationToRotate = new Point2D.Double(getX(), getY());

		Point2D locationDes = new Point2D.Double();

		AffineTransform.getRotateInstance(angleRadians - rotation,
				rotationPointCenter.x, rotationPointCenter.y).transform(
				currentLocationToRotate, locationDes);
		currentLocationToRotate.setLocation(locationDes);

		rotation = angleRadians;
		setLocation((int) locationDes.getX(), (int) locationDes.getY());
	}

	public int getOpacity() {
		return opacity;
	}

	public void setOpacity(int opacity) {
		this.opacity = opacity;
	}

	public Point getRotationPointCenter() {
		return rotationPointCenter;
	}

	public void setRotationPointCenter(Point rotationPointCenter) {
		this.rotationPointCenter = rotationPointCenter;
	}

	public float getRotation() {
		return rotation;
	}

	public void setRotation(float rotation) {
		this.rotation = rotation;
	}

	public Point getTargetPosition() {
		return targetPosition;
	}

	public void setTargetPosition(Point position) {
		this.targetPosition = position;
	}
	
	public Colors getBackgroundColors() {
		return backgroundColors;
	}

	public void setBackgroundColors(Colors backgroundColors) {
		this.backgroundColors = backgroundColors;
	}

	public Colors getBorderColors() {
		return borderColors;
	}

	public void setBorderColors(Colors borderColors) {
		this.borderColors = borderColors;
	}

	public boolean isPaintBorder() {
		return paintBorder;
	}

	public void setPaintBorder(boolean paintBorder) {
		this.paintBorder = paintBorder;
	}

	public Object getActionObject() {
		return actionObject;
	}

	public void setActionObject(Object actionObject) {
		this.actionObject = actionObject;
	}
}
