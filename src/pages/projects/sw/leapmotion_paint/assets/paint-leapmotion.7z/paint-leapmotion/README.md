paint-leapmotion
================

**Działa:**

* obsługa leapmotion i myszki
* wybieranie narzędzi i kolorów
* aby wybrać opcje za pomoca leap, wystarczy najechac na przycisk i po zmianie koloru bedzie wybrany

**TODO:**

* rozszerzyć kolor po najechaniu na niego
* przesuwanie obrazu
* dodatkowe narzędzia?

**DONE:**

* dodać spray'a do leap motion
* menu znika i sie pojawia jak mamy kilka palcy w różnej głębokości
* dodać kolory jak czarny/biały 
* zaokrąglanie końców lini (szczególnie dla gumki i pędzla)
* dodać podgląd wybranego narzędzia i koloru
* bug: czasem na leap motion nie znika menu z narzędziami
* dostosować obszary rysowania, menu