package com.ick.paint.gui.menu;

import java.awt.Container;
import java.awt.Point;

import aurelienribon.tweenengine.BaseTween;
import aurelienribon.tweenengine.Timeline;
import aurelienribon.tweenengine.Tween;
import aurelienribon.tweenengine.TweenCallback;
import aurelienribon.tweenengine.equations.Quart;

import com.ick.paint.gui.ImagePanel;
import com.ick.paint.gui.menu.buttons.RoundButton;
import com.ick.paint.gui.tween.TweenAnimationsTool;
import com.ick.paint.gui.tween.tweenaccessor.MenuButtonAccessor;
import com.ick.paint.tools.PaintTool;

public class ToolsMenu extends PaintMenu {

	public static final String[] TOOLSMENU = { PaintTool.BRUSH.toString(),
			PaintTool.PEN.toString(), PaintTool.ERASER.toString(),
			PaintTool.SPRAY.toString(), PaintTool.DRAG.toString() };
	public static final PaintTool[] TOOLS = { PaintTool.BRUSH, PaintTool.PEN,
			PaintTool.ERASER, PaintTool.SPRAY, PaintTool.DRAG };

	private Timeline showButtons;
	private Timeline hideButtons;
	private Timeline pushInButtons;

	private int radius = 150;
	private Point center;

    private boolean isToolAnimationFired;

	public ToolsMenu(Container container) {
		super(container);

		createButtons(container);
		addButtonsToView();
	}

	private void createButtons(Container container) {
		center = new Point(0, containerHeight / 3);
		buttonSizeX = 90;
		buttonSizeY = 90;
		buttons = new RoundButton[TOOLSMENU.length];

		for (int i = 0; i < TOOLSMENU.length; i++) {
			buttons[i] = new RoundButton(TOOLSMENU[i]);
			buttons[i].setActionObject(PaintTool.getBasicTool(TOOLS[i], (ImagePanel)container));
		}

	}

	private void addButtonsToView() {
		for (int i = 0; i < buttons.length; i++) {
			container.add(buttons[i]);
		}

        visible = true;
		getPushInToolsButtons().start(
				TweenAnimationsTool.getInstance().getTweenManager());
		TweenAnimationsTool.getInstance().start();
	}

	private Timeline getHideButtonsTimeline() {
		hideButtons = Timeline.createParallel();
		for (int i = 0; i < buttons.length; i++) {
			hideButtons.push(
					Tween.to(buttons[i], MenuButtonAccessor.POSITION, 300)
							.ease(Quart.IN)
							.target((float) center.getX(),
									(float) center.getY())).push(
					Tween.to(buttons[i], MenuButtonAccessor.OPACITY, 300)
							.ease(Quart.IN).target(0));
		}
        hideButtons
                .setCallbackTriggers(TweenCallback.BEGIN | TweenCallback.END)
                .setCallback(new TweenCallback() {
                    @Override
                    public void onEvent(int type, BaseTween<?> source) {
                        if (type == BEGIN) {
                            isToolAnimationFired = true;
                        } else if (type == END) {
                            visible = false;
                            isToolAnimationFired = false;
                        }
                    }
                });

		return hideButtons;
	}

	private Timeline getShowButtonsTimeline() {
		showButtons = Timeline.createParallel();
		for (int i = 0; i < buttons.length; i++) {
			showButtons.push(
					Tween.to(buttons[i], MenuButtonAccessor.POSITION, 300)
							.ease(Quart.IN)
							.target((float) buttons[i].getTargetPosition()
									.getX(),
									(float) buttons[i].getTargetPosition()
											.getY())).push(
					Tween.to(buttons[i], MenuButtonAccessor.OPACITY, 300)
							.ease(Quart.IN).target(255));
		}
		showButtons
				.setCallbackTriggers(TweenCallback.BEGIN | TweenCallback.END)
				.setCallback(new TweenCallback() {

					@Override
					public void onEvent(int type, BaseTween<?> source) {

						if (type == BEGIN) {
                            isToolAnimationFired = true;
						} else if (type == END) {
                            visible = true;
                            isToolAnimationFired = false;
						}
					}
				});

		return showButtons;
	}

	private Timeline getPushInToolsButtons() {
		pushInButtons = Timeline.createParallel();
		for (int i = buttons.length - 1; i >= 0; i--) {
			buttons[buttons.length - i - 1].setRotationPointCenter(center);
			buttons[buttons.length - i - 1].setBounds((int) center.getX()
					- buttonSizeX, (int) (center.getY() - radius), buttonSizeX,
					buttonSizeY);

			pushInButtons.push(Timeline
					.createSequence()
					.delay(400 * (buttons.length - i - 1))
					.push(Tween
							.to(buttons[buttons.length - i - 1],
									MenuButtonAccessor.POSITION, 300)
							.ease(Quart.IN)
							.target(0, buttons[buttons.length - i - 1].getY()))
					.push(Tween
							.to(buttons[buttons.length - i - 1],
									MenuButtonAccessor.ROTATE, 1000)
							.ease(Quart.OUT)
							.setCallbackTriggers(TweenCallback.END)
							.setCallback(new TweenCallback() {

                                @Override
                                public void onEvent(int type, BaseTween<?> source) {
                                    ((RoundButton) ((Tween) source).getTarget())
                                            .setTargetPosition(((RoundButton) ((Tween) source)
                                                    .getTarget()).getLocation());
                                }
                            })
							.target((float) Math.toRadians(i * 180
                                    / (buttons.length - 1)))));

		}
		pushInButtons
                .setCallbackTriggers(TweenCallback.END)
                .setCallback(new TweenCallback() {

                    @Override
                    public void onEvent(int type, BaseTween<?> source) {
                        getHideButtonsTimeline()
                                .start(TweenAnimationsTool.getInstance()
                                        .getTweenManager());
                    }
                });

		return pushInButtons;
	}

	@Override
	public void setVisible(boolean visible) {
        if (this.visible == visible)
            return;

        if (!isToolAnimationFired) {
            if (visible) {
                getShowButtonsTimeline()
                        .start(TweenAnimationsTool.getInstance()
                                .getTweenManager());
            } else {
                getHideButtonsTimeline()
                        .start(TweenAnimationsTool.getInstance()
                                .getTweenManager());
            }
            TweenAnimationsTool.getInstance().start();
        }
	}
}
