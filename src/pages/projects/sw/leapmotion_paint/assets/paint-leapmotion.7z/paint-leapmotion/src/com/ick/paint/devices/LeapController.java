package com.ick.paint.devices;

import java.awt.Color;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JLayeredPane;

import com.ick.paint.gui.ImagePanel;
import com.ick.paint.gui.menu.MenuPanel;
import com.ick.paint.gui.menu.buttons.InfoPanel;
import com.ick.paint.gui.menu.buttons.RectButton;
import com.ick.paint.gui.menu.buttons.RoundButton;
import com.ick.paint.tools.BasicTool;
import com.ick.paint.tools.Pen;
import com.leapmotion.leap.Controller;
import com.leapmotion.leap.Finger;
import com.leapmotion.leap.FingerList;
import com.leapmotion.leap.Frame;
import com.leapmotion.leap.Gesture;
import com.leapmotion.leap.Hand;
import com.leapmotion.leap.Vector;

public class LeapController extends Controller implements ActionListener {

	private ImagePanel imagePanel; // view
	private BasicTool tool; // model
	private MenuPanel menuPanel; // view
	private Color toolColor = Color.BLACK;

	private LeapPointer[] cursors;

	private Point[] lastPositions;
	private boolean leapMotionOn = false;
	private Thread frameThread;
	private int screenWidth;
	private int screenHeight;



    private class LeapPosition {
        public float x, y, z;
    }

	public LeapController(ImagePanel imagePanel, MenuPanel manuPanel) {
		this.imagePanel = imagePanel;
		this.menuPanel = manuPanel;
		this.menuPanel.addActionListener(this);

		cursors = new LeapPointer[5];
        lastPositions = new Point[5];
		initCursors();

		tool = new Pen(imagePanel);
        InfoPanel.setActiveTool(tool);

		screenWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
		screenHeight = Toolkit.getDefaultToolkit().getScreenSize().height;

		enableGesture(Gesture.Type.TYPE_KEY_TAP);
		enableGesture(Gesture.Type.TYPE_SCREEN_TAP);
		enableGesture(Gesture.Type.TYPE_CIRCLE);
    }

	public void start() {
		leapMotionOn = true;
		Runnable loop = new Runnable() {

			@Override
			public void run() {

				while (leapMotionOn) {
					try {
						if (isConnected()) {

							processFrame(frame());

							Thread.sleep(16);
						} else {
							System.out.println("Waiting for connect ...");
							Thread.sleep(500);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		};

		frameThread = new Thread(loop);
		frameThread.start();
	}

	protected void processFrame(Frame frame) {
		if (!frame.hands().isEmpty()) {
			Hand hand = frame.hands().get(0);
			FingerList fingers = hand.fingers();

			if (!fingers.isEmpty()) {
                processGestures(frame);
                processFingers(frame, fingers);

                hideNotAvailableCursors(fingers.count());
			}
		} else {
			hideNotAvailableCursors(0);
		}

		imagePanel.repaint();
	}

    private void processFingers(Frame frame, FingerList fingers) {
        List<LeapPosition> newPositions = getNormalizedFingerPositions(frame, fingers);
        sortLastPositionArray(newPositions);
        float minDepth = computeMinDepthFromAllFingers(newPositions);

        for (int i = 0; i < Math.min(fingers.count(), menuPanel.isVisible() ? 1 : 5); i++) {
            LeapPosition position = newPositions.get(i);
            positionChanged(i, position);

            if (minDepth < LeapParameters.DRAWING_DEPTH) {
                menuPanel.hide();
                draw(i);
            } else if (minDepth > LeapParameters.MENU_DEPTH) {
                menuPanel.show();
            } else {
                tool.stopDrawing();
                menuPanel.hide();
                setLastPosition(i, null, null);
            }

            if (menuPanel.isVisible()) {
                menuPanel.rollover((int) position.x, (int) position.y);
            }
        }
    }

    private void sortLastPositionArray(List<LeapPosition> newPositions) {
        Point[] newLastPositions = new Point[5];
        int index = 0;
        for (LeapPosition newPosition : newPositions) {
            int size = countNotNullItems(lastPositions);
            if(index >= size)
                break;

            Point p =  new Point((int)newPosition.x, (int)newPosition.y);
            newLastPositions[index] = getClosestValue(p, lastPositions);
            ++index;
        }

        lastPositions = newLastPositions;
    }

    private List<LeapPosition> getNormalizedFingerPositions(Frame frame, FingerList fingers) {
        List<LeapPosition> newPositions = new ArrayList<LeapPosition>();
        for (Finger finger : fingers) {
            Vector intersection = frame.interactionBox().normalizePoint(finger.tipPosition(), true);
            if (!Float.isNaN(intersection.getX()) && !Float.isNaN(intersection.getY())
                    && !Float.isNaN(intersection.getZ())) {
                newPositions.add(computePostion(intersection));
            }
        }
        return newPositions;
    }

    private int countNotNullItems(Point[] lastPositions) {
        int size = 0;
        for(Point p : lastPositions) {
            if (p != null)
                ++size;
        }
        return size;
    }

    private float computeMinDepthFromAllFingers(List<LeapPosition> newPositions) {
        float minDepth = 1.0f;
        for (LeapPosition p : newPositions)
            minDepth = Math.min(minDepth, p.z);
        return minDepth;
    }

    private void processGestures(Frame frame) {
        for (Gesture gesture : frame.gestures()) {

            /*
             * System.out.println("Gesture: " + Gesture.Type.TYPE_CIRCLE
             * + " valid: " + gesture.isValid() + " state: " +
             * gesture.state());
             */

            if (gesture.type().equals(Gesture.Type.TYPE_SCREEN_TAP)
                    && gesture.isValid()) {

                /*
                 * com.leapmotion.leap.Vector intersection = frame
                 * .interactionBox().normalizePoint(
                 * gesture.pointables().get(0) .tipPosition(), true);
                 *
                 * if (!Float.isNaN(intersection.getX()) &&
                 * !Float.isNaN(intersection.getY()) &&
                 * !Float.isNaN(intersection.getZ())) {
                 *
                 * float[] position = computePostion(intersection);
                 *
                 * positionChanged(0, position);
                 * System.out.println("Gesture position" +
                 * Arrays.toString(position)); menuPanel.click((int)
                 * position[0], (int) position[1]); }
                 */
            }
        }
    }

    private LeapPosition computePostion(Vector intersection) {
		Point cursorPosition = new Point(
				(int) (intersection.getX() * (float) screenWidth),
				(int) ((float) screenHeight - intersection.getY() * (float) screenHeight));
        LeapPosition lp = new LeapPosition();
        lp.x = (float) cursorPosition.getX();
        lp.y = (float) cursorPosition.getY();
        lp.z = intersection.getZ();
		return lp;
	}

	private void positionChanged(int cursorId, LeapPosition position) {
		if (tool != null)
			cursors[cursorId].setFillColor(tool.getColor());
		cursors[cursorId].setPosition((int) position.x, (int) position.y, position.z);
	}

	private void hideNotAvailableCursors(int numOfFingers) {
		for (int i = numOfFingers; i < cursors.length; i++) {
			cursors[i].setVisible(false);
		}
	}

	private void initCursors() {
		JLayeredPane layeredPane = imagePanel.getRootPane().getLayeredPane();

		for (int i = 0; i < cursors.length; i++) {
			cursors[i] = new LeapPointer();
			layeredPane.add(cursors[i], JLayeredPane.DRAG_LAYER);
		}
	}

	public void draw(int fingerId) {
		if (tool != null && !menuPanel.isVisible()) {
            if (cursors[fingerId].isPressed()) {
                tool.setColor(toolColor);
                tool.setWidth(cursors[fingerId].getSize().width);

                if (lastPositions[fingerId] == null) {
                    setLastPosition(fingerId,
                            cursors[fingerId].getXCenterPosition(),
                            cursors[fingerId].getYCenterPosition());
                }

                tool.draw(lastPositions[fingerId].x, lastPositions[fingerId].y,
                        cursors[fingerId].getXCenterPosition(),
                        cursors[fingerId].getYCenterPosition());

            }
            imagePanel.repaint();
		}
		setLastPosition(fingerId, cursors[fingerId].getXCenterPosition(),
				cursors[fingerId].getYCenterPosition());
	}

    private Point getClosestValue(Point value, Point[] lastPositions) {
        Point closestPoint = new Point();
        float minDistance = Float.MAX_VALUE;
        for (Point lastPos : lastPositions) {
            if (lastPos == null)
                continue;

            float distance = calculateDistance(lastPos, value);
            if (distance < minDistance) {
                minDistance = distance;
                closestPoint = lastPos;
            }
        }
        return closestPoint;
    }

    private float calculateDistance(Point lastPos, Point cursor) {
        int xDiff = (int)Math.abs(lastPos.getX() - cursor.getX());
        int yDiff = (int)Math.abs(lastPos.getY() - cursor.getY());
        return (float)Math.sqrt(xDiff * xDiff + yDiff * yDiff);
    }

    private void setLastPosition(int fingerId, Integer x, Integer y) {
        if (x == null || y == null)
            lastPositions[fingerId] = null;
        else {
            if (lastPositions[fingerId] == null)
                lastPositions[fingerId] = new Point();
            lastPositions[fingerId].x = x;
            lastPositions[fingerId].y = y;
        }
	}

	public void stop() {
		leapMotionOn = false;
		try {
			if (frameThread != null)
				frameThread.join();
		} catch (InterruptedException ex) {
			ex.printStackTrace();
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// System.out.println("Action performed: " + e);
		if (hasClickedOnTool(e)) {
			RoundButton button = (RoundButton) e.getSource();
			setTool((BasicTool) button.getActionObject());
            InfoPanel.setActiveTool(tool);
		} else if (hasClickedOnColor(e)) {
			RectButton button = (RectButton) e.getSource();
			toolColor = (Color) button.getActionObject();
            InfoPanel.setActualColor(toolColor);
		}
	}

    private boolean hasClickedOnColor(ActionEvent e) {
        return e.getSource() instanceof RectButton;
    }

    private boolean hasClickedOnTool(ActionEvent e) {
        return e.getSource() instanceof RoundButton;
    }

    public BasicTool getTool() {
		return tool;
	}

	public void setTool(BasicTool tool) {
		this.tool = tool;
	}

}
