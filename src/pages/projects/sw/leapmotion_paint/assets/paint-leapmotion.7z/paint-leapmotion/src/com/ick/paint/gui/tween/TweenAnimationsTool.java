package com.ick.paint.gui.tween;

import javax.swing.SwingUtilities;

import aurelienribon.tweenengine.TweenManager;

public class TweenAnimationsTool {

	private static volatile TweenAnimationsTool instance = null;

	private TweenManager tweenManager = new TweenManager();
    private Thread thread = null;
	private boolean isRunning = false;
	
	private Runnable loop = new Runnable() {
		private long lastMillis;

		@Override
		public void run() {
			lastMillis = System.currentTimeMillis();

			while (isRunning) {
				try {
					final long millis = System.currentTimeMillis();
					final long delta = millis - lastMillis;
					lastMillis = millis;

					SwingUtilities.invokeAndWait(new Runnable() {
						@Override
						public void run() {
							update((int) delta);
						}
					});
					Thread.sleep(16);

				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		}
	};

	private TweenAnimationsTool() {
	}
	 
    public static TweenAnimationsTool getInstance() {
        if (instance == null) {
            synchronized (TweenAnimationsTool.class) {
                if (instance == null) {
                    instance = new TweenAnimationsTool();
                }
            }
        }
        return instance;
    }
 
	public TweenAnimationsTool start() {
		thread = new Thread(loop);
		thread.start();
		isRunning = true;
		return this;
	}

	public void stop() {
		isRunning = false;
		try {
			thread.join();
		} catch (InterruptedException ex) {
			ex.printStackTrace();
		}
	}

	protected void update(int elapsedMillis) {
		tweenManager.update(elapsedMillis);
	}

	public boolean isRunning() {
		return isRunning;
	}

	public void setRunning(boolean isRunning) {
		this.isRunning = isRunning;
	}

	public TweenManager getTweenManager() {
		return tweenManager;
	}

	public void setTweenManager(TweenManager tweenManager) {
		this.tweenManager = tweenManager;
	};
	
	
	
}
