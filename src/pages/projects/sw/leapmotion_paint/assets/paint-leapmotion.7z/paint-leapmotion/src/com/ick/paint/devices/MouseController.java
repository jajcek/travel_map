package com.ick.paint.devices;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import com.ick.paint.gui.ImagePanel;
import com.ick.paint.gui.menu.MenuPanel;
import com.ick.paint.gui.menu.buttons.InfoPanel;
import com.ick.paint.gui.menu.buttons.RectButton;
import com.ick.paint.gui.menu.buttons.RoundButton;
import com.ick.paint.tools.BasicTool;
import com.ick.paint.tools.Pen;

/**
 * Created by jajcek on 19.12.13.
 */
public class MouseController implements MouseListener, MouseMotionListener,
		ActionListener {

	private ImagePanel imagePanel; // view
	private BasicTool tool; // model
	private MenuPanel menuPanel; // view
	private Color toolColor = Color.BLACK;

	private int xPos;
	private int yPos;
	private int buttonIdPressed;

	public MouseController(ImagePanel imagePanel, MenuPanel manuPanel) {
		this.imagePanel = imagePanel;
		imagePanel.addMouseListener(this);
		imagePanel.addMouseMotionListener(this);
		this.menuPanel = manuPanel;
		this.menuPanel.addActionListener(this);

		tool = new Pen(imagePanel);
		InfoPanel.setActiveTool(tool);
		InfoPanel.setActualColor(toolColor);
	}

	public ImagePanel getImagePanel() {
		return imagePanel;
	}

	public void setImagePanel(ImagePanel imagePanel) {
		this.imagePanel = imagePanel;
	}

	public BasicTool getTool() {
		return tool;
	}

	public void setTool(BasicTool tool) {
		this.tool = tool;
	}

	public MenuPanel getMenuPanel() {
		return menuPanel;
	}

	public void setMenuPanel(MenuPanel menuPanel) {
		this.menuPanel = menuPanel;
		menuPanel.addActionListener(this);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if (e.getButton() == MouseEvent.BUTTON3) {
			if (menuPanel.isVisible()) {
				menuPanel.hide();
			} else {
				menuPanel.show();
			}
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent e) {
	}

	@Override
	public void mousePressed(MouseEvent e) {
		if (e.getButton() == MouseEvent.BUTTON1) {
			buttonIdPressed = 1;
		}

		xPos = e.getX();
		yPos = e.getY();

		if (tool != null && !menuPanel.isVisible() && buttonIdPressed == 1) {
			draw(e);
		}
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		buttonIdPressed = -1;
		if (tool != null) // leciał null pointer ;/
			tool.stopDrawing();
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		if (tool != null && !menuPanel.isVisible() && buttonIdPressed == 1) {
			draw(e);
		}

		xPos = e.getX();
		yPos = e.getY();
	}

    private void draw(MouseEvent e) {
        tool.setColor(toolColor);
        tool.draw(xPos, yPos, e.getX(), e.getY());
        imagePanel.repaint();
    }

	@Override
	public void mouseMoved(MouseEvent e) {
		// System.out.println("mouse x: " + e.getX() + ", y: " + e.getY());
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.println("Action performed: " + e);
		if (hasClickedOnTool(e)) {
			RoundButton button = (RoundButton) e.getSource();
			setTool((BasicTool) button.getActionObject());
			InfoPanel.setActiveTool(tool);
		} else if (hasClickedOnColor(e)) {
			RectButton button = (RectButton) e.getSource();
			toolColor = (Color) button.getActionObject();
			InfoPanel.setActualColor(toolColor);
			imagePanel.repaint();
		}
	}

	private boolean hasClickedOnColor(ActionEvent e) {
		return e.getSource() instanceof RectButton;
	}

	private boolean hasClickedOnTool(ActionEvent e) {
		return e.getSource() instanceof RoundButton;
	}
}
