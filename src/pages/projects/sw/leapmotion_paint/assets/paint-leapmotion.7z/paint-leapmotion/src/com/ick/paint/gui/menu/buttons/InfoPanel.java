package com.ick.paint.gui.menu.buttons;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

import com.ick.paint.tools.BasicTool;

public class InfoPanel  extends JLabel {

	private static final long serialVersionUID = 1L;
	private static JPanel currentColorInfo;
	private static JLabel currentToolInfo;
	private static Color currentColor = Color.white;
	
	public InfoPanel(JPanel panel) {

		setLayout(new GridLayout());
		
		currentColorInfo = new JPanel();
		currentToolInfo = new JLabel("No tool");
		
		currentColorInfo.setBounds(50, 0, 35, 35);
		currentToolInfo.setBounds(100, 0, 35, 35);
		
		setBounds(10, 10, 150, 50);
		
		this.setBackground(new Color(100,100,100,50));
		this.setForeground(new Color(150,150,150,50));
		
		add(currentColorInfo);
		add(currentToolInfo);
		panel.add(this);
		
	}
	
	public void paint(Graphics g) {
		
		g.setColor(getBackground());
		g.fillRoundRect(getX(), getY(), getWidth()-15, getHeight()-15, 10, 10);
		g.setColor(getForeground());
		g.drawRoundRect(getX(), getY(), getWidth()-15, getHeight()-15, 10, 10);
		
		g.setColor(currentColor);
		g.fillRoundRect(getX() + 2, getY() + 2, getWidth()-115, getHeight()-20, 10, 10);
		g.setColor(currentColor.darker());
		g.drawRoundRect(getX() + 2, getY() + 2, getWidth()-115, getHeight()-20, 10, 10);
		
		g.setColor(Color.black);
		g.drawString(currentToolInfo.getText(), getX() + 70, getY() + 22);
	}

	public static void setActiveTool(BasicTool tool) {
		currentToolInfo.setText(tool.toString().toUpperCase());
	}
	
	public static void setActualColor(Color color) {
		currentColor = color;
	}
}
