package com.ick.paint.gui.menu;

import java.awt.Container;
import java.awt.event.ActionListener;

public class MenuPanel {
	private ToolsMenu toolsPanel;
	private ColorsMenu colorsPanel;

	public MenuPanel(Container container) {
		toolsPanel = new ToolsMenu(container);
		colorsPanel = new ColorsMenu(container);
	}

	public boolean isVisible() {
		return toolsPanel.isVisible() && colorsPanel.isVisible();
	}

	public void show() {
		if (!isVisible()) {
			toolsPanel.setVisible(true);
			colorsPanel.setVisible(true);
		}
	}

	public void hide() {
		if (isVisible()) {
			toolsPanel.setVisible(false);
			colorsPanel.setVisible(false);
		}
	}

	public void addActionListener(ActionListener actionListener) {
		toolsPanel.addActionListener(actionListener);
		colorsPanel.addActionListener(actionListener);
	}

	public void rollover(int x, int y) {
		toolsPanel.rollover(x, y);
		colorsPanel.rollover(x, y);
	}

}
