package com.ick.paint.tools;

import com.ick.paint.gui.ImagePanel;

import java.awt.*;

/**
 * Created by jajcek on 21.12.13.
 */
public abstract class BasicTool {
	protected ImagePanel imagePanel;

    protected String toolName = "";

	protected Color color = Color.BLACK;
	protected int width = 1;

	public BasicTool(ImagePanel imagePanel) {
		this.imagePanel = imagePanel;
	}

	public void draw(int xStart, int yStart, int xEnd, int yEnd){
		useTool(imagePanel.getImageX(xStart), imagePanel.getImageY(yStart),
				imagePanel.getImageX(xEnd), imagePanel.getImageY(yEnd));
	}
	
	protected abstract void useTool(int xStart, int yStart, int xEnd, int yEnd);

    public void stopDrawing() {}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}

    @Override
    public String toString() {
        return toolName;
    }
}
