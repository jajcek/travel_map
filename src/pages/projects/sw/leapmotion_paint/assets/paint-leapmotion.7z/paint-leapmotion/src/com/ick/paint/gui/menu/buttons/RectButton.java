package com.ick.paint.gui.menu.buttons;

import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import com.ick.paint.gui.MainWindow;

public class RectButton extends MenuButton {

	private int xZoom = 10;
	private int yZoom = 10;
	private int position = 0; // 0-normal -1 left 1 right

	private static final long serialVersionUID = 1L;

	public RectButton() {
		super();
	}

	public RectButton(Point rotationPointCenter) {
		super();
		this.rotationPointCenter = rotationPointCenter;
	}

	public RectButton(String label) {
		super();
		setText(label);
	}

	protected void paintComponent(Graphics graphic) {
		Graphics2D g = (Graphics2D) graphic;
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER,
				opacity / 255f));

		if (getModel().isSelected()) {
			g.setColor(backgroundColors.getSelected());
		} else if (getModel().isPressed()) {
			g.setColor(backgroundColors.getClicked());
		} else {
			g.setColor(backgroundColors.getStandard());
		}

		g.fillRect(0, 0, getSize().width - 1, getSize().height - 1);

		setForeground(foregroundColor); // tu przezroczystość nic nie daje ;(

		super.paintComponent(g);
	}

	protected void paintBorder(Graphics g) {
		if (paintBorder) {
			Graphics2D g2d = (Graphics2D) g;
			g2d.setComposite(AlphaComposite.getInstance(
					AlphaComposite.SRC_OVER, opacity / 255f));

			if (getModel().isSelected()) {
				g2d.setColor(borderColors.getSelected());
			} else if (getModel().isPressed()) {
				g2d.setColor(borderColors.getClicked());
			} else {
				g2d.setColor(borderColors.getStandard());
			}
			g2d.setStroke(new BasicStroke(1.0f));
			g2d.drawRect(0, 0, getSize().width - 1, getSize().height - 1);
		}
	}

	public boolean contains(int x, int y) {
		// to tak na pałe ale już mam dosyć
        if (!MainWindow.USE_LEAPMOTION) {
            return super.contains(x, y);
		}

		if (shape == null || !shape.getBounds().equals(getBounds())) {
			shape = new Rectangle2D.Float(getX(), getY(), getWidth(),
					getHeight());
		}
		return shape.contains(x, y);
	}

	@Override
	public void setSelected(boolean selected) {

		if (isSelected() == selected)
			return;

		super.setSelected(selected);

		if (selected) {
			setBounds(getX() - xZoom, getY() - xZoom, getWidth() + 2 * xZoom,
					getHeight() + 2 * xZoom);
		} else {
			setBounds(getX() + yZoom, getY() + yZoom, getWidth() - 2 * yZoom,
					getHeight() - 2 * yZoom);
		}

	}

	public void moveToPosition(int position) {
		setBounds(getX() - (this.position - position) * xZoom, getY(),
				getWidth(), getHeight());
		this.position = position;
	}
	
	public int getPosition() {
		return position;
	}
}
