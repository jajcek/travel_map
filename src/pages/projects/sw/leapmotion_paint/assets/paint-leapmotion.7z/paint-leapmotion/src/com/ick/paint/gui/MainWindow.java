package com.ick.paint.gui;

import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;

import javax.swing.JFrame;

import aurelienribon.tweenengine.Tween;

import com.ick.paint.devices.LeapController;
import com.ick.paint.devices.MouseController;
import com.ick.paint.gui.menu.MenuPanel;
import com.ick.paint.gui.menu.buttons.InfoPanel;
import com.ick.paint.gui.menu.buttons.MenuButton;
import com.ick.paint.gui.tween.TweenAnimationsTool;
import com.ick.paint.gui.tween.tweenaccessor.MenuButtonAccessor;

public class MainWindow extends JFrame {
	
	private static final long serialVersionUID = 1L;

	public static final boolean ALLOW_FULLSCREEN = true;
	public static final boolean USE_LEAPMOTION = false;
	
	private GraphicsDevice device;
	public ImagePanel imagePanel;
	private MenuPanel menuPanel;
	public InfoPanel infoPanel;

	private Object controller; // mouse albo leap

	public static boolean isLeapMotionOn = false;

	public MainWindow(GraphicsDevice device) {
		super(device.getDefaultConfiguration());
		this.setDevice(device);

		setTitle("Leap motion paint");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		boolean isFullScreen = device.isFullScreenSupported();
		setUndecorated(isFullScreen && ALLOW_FULLSCREEN);
		if (isFullScreen && ALLOW_FULLSCREEN) {// Full-screen mode
			setResizable(false);
			device.setFullScreenWindow(this);
			validate();
		} else {// Windowed mode
			setResizable(true);
			setBounds(150, 100, 1200, 700);
			setVisible(true);
		}
	}

	public static void main(String[] args) {
		GraphicsEnvironment env = GraphicsEnvironment
				.getLocalGraphicsEnvironment();

		Tween.registerAccessor(MenuButton.class, new MenuButtonAccessor());

		MainWindow mainWindow = new MainWindow(env.getDefaultScreenDevice());
		mainWindow.initComponents();

	}

	private void initComponents() {

		// panel do rysowania
		imagePanel = new ImagePanel();
		add(imagePanel);
		validate();

		menuPanel = new MenuPanel(imagePanel);
		validate();

		infoPanel = new InfoPanel(imagePanel);
		
		if (USE_LEAPMOTION) {
			LeapController leapMotionController = new LeapController(
					imagePanel, menuPanel);
			leapMotionController.start();
			isLeapMotionOn = true;
			controller = leapMotionController;
		} else {
			System.out.println("MouseController is on");
			controller = new MouseController(imagePanel, menuPanel);
		}

		validate();
	}

	@Override
	public void dispose() {
		TweenAnimationsTool tweenAnimationsTool = TweenAnimationsTool
				.getInstance();
		if (tweenAnimationsTool.isRunning()) {
			tweenAnimationsTool.stop();
		}

		if (controller instanceof LeapController) {
			((LeapController) controller).stop();
		}

		super.dispose();
	}

	public GraphicsDevice getDevice() {
		return device;
	}

	public void setDevice(GraphicsDevice device) {
		this.device = device;
	}
}
